cd trce_src
make clean
make
cd ../as_src
make clean
make
cd ..
ls bin
